﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;

namespace CmsTemplate.Etka
{
    using CMS.Mails;
    using CMS.Pages;
    using CMS.Pages.Web;
    using CMS.Templates;

    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            //Membership.DeleteUser("sau241179");

            PagesEnvironment.FolderPath = Server.MapPath("~/Pages");
            HtmlTemplateEnvironment.FolderPath = Server.MapPath("~/Templates");
            MailTemplateEnvironment.FolderPath = Server.MapPath("~/Mails");
            CMS.Pages.Web.PageRoutes.Init();
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {

        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}