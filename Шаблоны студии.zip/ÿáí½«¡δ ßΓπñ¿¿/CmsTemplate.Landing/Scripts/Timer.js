﻿function CountBox(year, month, day, hour, minute, sec) {
    dateFuture = new Date(year, month, day, hour, minute, sec);

    dateNow = new Date;
    amount = dateFuture.getTime() - dateNow.getTime() + 5;
    delete dateNow;
    if (amount < 0) {
        out = "<div class='countbox-num'><div id='countbox-days1'><span></span>0</div><div id='countbox-days2'><span></span>0</div><div id='countbox-days-text'></div></div>" +
        "<div class='countbox-space'></div>" +
        "<div class='countbox-num'><div id='countbox-hours1'><span></span>0</div><div id='countbox-hours2'><span></span>0</div><div id='countbox-hours-text'></div></div>" +
        "<div class='countbox-space'></div>" +
        "<div class='countbox-num'><div id='countbox-mins1'><span></span>0</div><div id='countbox-mins2'><span></span>0</div><div id='countbox-mins-text'></div></div>" +
        "<div class='countbox-space'></div>" +
        "<div class='countbox-num'><div id='countbox-secs1'><span></span>0</div><div id='countbox-secs2'><span></span>0</div><div id='countbox-secs-text'></div></div>";
        document.getElementById("countbox").innerHTML = out
    } else {
        days = 0;
        days1 = 0;
        days2 = 0;
        hours = 0;
        hours1 = 0;
        hours2 = 0;
        mins = 0;
        mins1 = 0;
        mins2 = 0;
        secs = 0;
        secs1 = 0;
        secs2 = 0;
        out = "";
        amount = Math.floor(amount / 1e3);
        days = Math.floor(amount / 86400);
        days1 = (days >= 10) ? days.toString().charAt(0) : '0';
        days2 = (days >= 10) ? days.toString().charAt(1) : days.toString().charAt(0);
        amount = amount % 86400;
        hours = Math.floor(amount / 3600);
        hours1 = (hours >= 10) ? hours.toString().charAt(0) : '0';
        hours2 = (hours >= 10) ? hours.toString().charAt(1) : hours.toString().charAt(0);
        amount = amount % 3600;
        mins = Math.floor(amount / 60);
        mins1 = (mins >= 10) ? mins.toString().charAt(0) : '0';
        mins2 = (mins >= 10) ? mins.toString().charAt(1) : mins.toString().charAt(0);
        amount = amount % 60;
        secs = Math.floor(amount);
        secs1 = (secs >= 10) ? secs.toString().charAt(0) : '0';
        secs2 = (secs >= 10) ? secs.toString().charAt(1) : secs.toString().charAt(0);
        out = "<div class='countbox-num'><div id='countbox-days1'><span></span>" + days1 + "</div><div id='countbox-days2'><span></span>" + days2 + "</div><div id='countbox-days-text'></div></div>" +
        "<div class='countbox-space'></div>" +
        "<div class='countbox-num'><div id='countbox-hours1'><span></span>" + hours1 + "</div><div id='countbox-hours2'><span></span>" + hours2 + "</div><div id='countbox-hours-text'></div></div>" +
        "<div class='countbox-space'></div>" +
        "<div class='countbox-num'><div id='countbox-mins1'><span></span>" + mins1 + "</div><div id='countbox-mins2'><span></span>" + mins2 + "</div><div id='countbox-mins-text'></div></div>" +
        "<div class='countbox-space'></div>" +
        "<div class='countbox-num'><div id='countbox-secs1'><span></span>" + secs1 + "</div><div id='countbox-secs2'><span></span>" + secs2 + "</div><div id='countbox-secs-text'></div></div>";
        document.getElementById("countbox").innerHTML = out;
        setTimeout("CountBox(" + year + "," + month + "," + day + "," + hour + "," + minute + "," + sec + ")", 1e3);
    }
}

$(document).ready(function () {
    $('[data-toggle=Timer]').html(unescape("%20%20%20%20%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%22%3E%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%75%6E%74%62%6F%78%2D%6E%75%6D%22%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%64%61%79%73%31%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%64%61%79%73%32%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%64%61%79%73%2D%74%65%78%74%22%3E%3C%2F%64%69%76%3E%3C%2F%64%69%76%3E%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%75%6E%74%62%6F%78%2D%73%70%61%63%65%22%3E%3C%2F%64%69%76%3E%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%75%6E%74%62%6F%78%2D%6E%75%6D%22%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%68%6F%75%72%73%31%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%68%6F%75%72%73%32%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%68%6F%75%72%73%2D%74%65%78%74%22%3E%3C%2F%64%69%76%3E%3C%2F%64%69%76%3E%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%75%6E%74%62%6F%78%2D%73%70%61%63%65%22%3E%3C%2F%64%69%76%3E%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%75%6E%74%62%6F%78%2D%6E%75%6D%22%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%6D%69%6E%73%31%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%6D%69%6E%73%32%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%6D%69%6E%73%2D%74%65%78%74%22%3E%3C%2F%64%69%76%3E%3C%2F%64%69%76%3E%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%75%6E%74%62%6F%78%2D%73%70%61%63%65%22%3E%3C%2F%64%69%76%3E%3C%64%69%76%20%63%6C%61%73%73%3D%22%63%6F%75%6E%74%62%6F%78%2D%6E%75%6D%22%3E%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%73%65%63%73%31%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%73%65%63%73%32%22%3E%3C%73%70%61%6E%3E%3C%2F%73%70%61%6E%3E%30%3C%2F%64%69%76%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%3C%64%69%76%20%69%64%3D%22%63%6F%75%6E%74%62%6F%78%2D%73%65%63%73%2D%74%65%78%74%22%3E%3C%2F%64%69%76%3E%0A%20%20%20%20%20%20%20%20%3C%2F%64%69%76%3E%0A%20%20%20%20%3C%2F%64%69%76%3E"));
    var time = $('[data-toggle=Timer]').data("value");
    var timeData = time.toString().split(" ");
    CountBox(timeData[0], timeData[1] - 1, timeData[2], timeData[3], timeData[4], timeData[5]);
});

